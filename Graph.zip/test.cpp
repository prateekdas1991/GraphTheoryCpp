#include <iostream>
#include <vector>
#include <unordered_set>
#include <algorithm>

using namespace std;

int maximalNetworkRank(int n, vector<vector<int>>& roads) {
    // Step 1: Build the adjacency list
    vector<unordered_set<int>> adj(n);
    
    // Fill the adjacency list with roads
    for (const auto& road : roads) {
        int a = road[0], b = road[1];
        adj[a].insert(b);
        adj[b].insert(a);
    }
    
    // Step 2: Calculate the maximal network rank
    int maxRank = 0;
    
    // Loop through each pair of cities i, j (i < j)
    for (int i = 0; i < n; ++i) {
        for (int j = i + 1; j < n; ++j) {
            // Total number of roads connected to i or j
            int rank = adj[i].size() + adj[j].size();
            
            // If there is a road between city i and city j, subtract 1
            if (adj[i].count(j)) {
                rank -= 1;
            }
            
            // Update maxRank
            maxRank = max(maxRank, rank);
        }
    }
    
    return maxRank;
}

int main() {
    // Test case 1
    int n = 9;
    vector<vector<int>> roads = {{0, 1}, {0, 6}, {0, 7}, {0, 8}, {6, 3}, {6, 0}, {8, 5}, {5, 2}, {5, 4}};
    
    // Output the maximal network rank
    cout << "Maximal Network Rank: " << maximalNetworkRank(n, roads) << endl;

    return 0;
}
#include <iostream>
#include <list>
#include "Graph.cpp"


using namespace std;

int main(){
    cout << "Hello World!" << endl;

    vector<string> cities = {"Delhi", "London", "Paris", "New York"};
    Graph g(cities);

    g.addEdge("Delhi", "London");
    g.addEdge("New York", "London");
    g.addEdge("Delhi", "Paris");
    g.addEdge("Paris", "New York");

    g.printAdjList();
    return 0;
}